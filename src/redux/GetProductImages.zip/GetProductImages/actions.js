import {GET_PHOTOS_REQUEST, GET_PHOTOS_SUCCESS, GET_PHOTOS_FAIL} from "./constants";
import {store} from '../../redux/index.js'
import Client from '../../Contentful';

async function getProduct(dispatch, product) {
    let cached = false;
    try {
        let response = await Client.getEntry({
            'content_type': 'bodyffyStore',
            'fields.slug': product,
        });
        cached = true;
        let items = response.items;
        let item = items.map(i => {
            return i
        });
        let photos = item.fields.photos.map(image =>
            image.fields.file.url);
        if (cached) {
            dispatch({
                type: GET_PHOTOS_SUCCESS,
                payload: {photos, item}
            })
        }
    } catch (e) {
        dispatch({
            type: GET_PHOTOS_FAIL,
            error: true,
            payload: new Error(e),
        })
    }
}

export function getPhotos(dispatch, getState) {
    let product = store.getState().product;
    return (dispatch) => {
        dispatch({
            type: GET_PHOTOS_REQUEST,
            payload: product,
        })
        getProduct(product)
    }
}

// export function getPhotos(dispatch, getState) {
//     let product = store.getState().product;
//     return (dispatch) => {
//         dispatch({
//             type: GET_PHOTOS_REQUEST,
//             payload: product,
//         })
//         setTimeout(() => {
//             dispatch({
//                 type: GET_PHOTOS_SUCCESS,
//                 payload: [1, 2, 3, 4, 5],
//             })
//         }, 1000)
//     }
// }